
from flask import Flask, request, render_template
import requests
import os

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Your Hugging Face API key
API_URL = "https://api-inference.huggingface.co/models/openai/whisper-small"
headers = {"Authorization": "Bearer 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"}

def transcribe_with_whisper_api(audio_file_path):
    with open(audio_file_path, "rb") as f:
        response = requests.post(API_URL, headers=headers, data=f)
    if response.status_code == 200:
        return response.json().get("text", "")
    else:
        return "Transcription failed."

def summarize_text(text):
    return text[:300] + "..."  # Placeholder

def generate_newsletter(summary):
    return f"<h2>Newsletter</h2><p>{summary}</p>"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload-audio", methods=["POST"])
def upload_audio():
    file = request.files["audio_file"]
    if file:
        filename = os.path.join(UPLOAD_FOLDER, "audio.mp3")
        file.save(filename)
        transcript = transcribe_with_whisper_api(filename)
        summary = summarize_text(transcript)
        newsletter = generate_newsletter(summary)
        return render_template("result.html", newsletter=newsletter, transcript=transcript)
    return "No file uploaded", 400

if __name__ == "__main__":
    app.run(debug=True)
